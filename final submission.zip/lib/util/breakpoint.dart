class Breakpoint {
  static const int md = 768;
  static const int lg = 1200;
}